
#include "pprintf.h"
char sprintfBuffer[sprintfBufferSz];


